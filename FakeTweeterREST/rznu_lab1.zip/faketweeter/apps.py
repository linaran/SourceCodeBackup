from django.apps import AppConfig


class FaketweeterConfig(AppConfig):
    name = 'faketweeter'
